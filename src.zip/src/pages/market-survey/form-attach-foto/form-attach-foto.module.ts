import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FormAttachFotoPage } from './form-attach-foto';

@NgModule({
  declarations: [
    FormAttachFotoPage,
  ],
  imports: [
    IonicPageModule.forChild(FormAttachFotoPage),
  ],
})
export class FormAttachFotoPageModule {}
