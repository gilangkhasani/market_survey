import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewDetailOfflinePage } from './view-detail-offline';

@NgModule({
  declarations: [
    ViewDetailOfflinePage,
  ],
  imports: [
    IonicPageModule.forChild(ViewDetailOfflinePage),
  ],
})
export class ViewDetailOfflinePageModule {}
