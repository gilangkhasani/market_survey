import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FormAttachFotoOfflinePage } from './form-attach-foto-offline';

@NgModule({
  declarations: [
    FormAttachFotoOfflinePage,
  ],
  imports: [
    IonicPageModule.forChild(FormAttachFotoOfflinePage),
  ],
})
export class FormAttachFotoOfflinePageModule {}
