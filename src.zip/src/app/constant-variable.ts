export const ConstantVariable:any = {
    //URL API
    APIURL : "https://itbsjabartsel.com/ionium2/",
    apiURLMarketSUrvey : 'https://itbsjabartsel.com/marvel/api/',
    
    //firebaseConfig
   apiKey: "AIzaSyCpn2mMN6SkHyEO82MYTkuN1UXKUVzyrJ4",
   authDomain: "first-project-22cd8.firebaseapp.com",
   databaseURL: "https://first-project-22cd8.firebaseio.com",
   projectId: "first-project-22cd8",
   storageBucket: "first-project-22cd8.appspot.com",
   messagingSenderId: "557904783877"
};